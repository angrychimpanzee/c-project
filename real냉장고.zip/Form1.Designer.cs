﻿namespace real냉장고
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            panel5 = new Panel();
            panel6 = new Panel();
            label1 = new Label();
            button6 = new Button();
            label2 = new Label();
            label3 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(1127, 42);
            button1.Name = "button1";
            button1.Size = new Size(93, 48);
            button1.TabIndex = 0;
            button1.Text = "재료추가";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(1226, 42);
            button2.Name = "button2";
            button2.Size = new Size(93, 48);
            button2.TabIndex = 1;
            button2.Text = "삭제";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(1325, 42);
            button3.Name = "button3";
            button3.Size = new Size(93, 48);
            button3.TabIndex = 2;
            button3.Text = "전체확인";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(1424, 42);
            button4.Name = "button4";
            button4.Size = new Size(93, 48);
            button4.TabIndex = 3;
            button4.Text = "월데이터";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // panel5
            // 
            panel5.Location = new Point(632, 671);
            panel5.Name = "panel5";
            panel5.Size = new Size(885, 129);
            panel5.TabIndex = 7;
            // 
            // panel6
            // 
            panel6.BackgroundImage = Properties.Resources.냉장고;
            panel6.BackgroundImageLayout = ImageLayout.Stretch;
            panel6.Location = new Point(56, 144);
            panel6.Name = "panel6";
            panel6.Size = new Size(473, 656);
            panel6.TabIndex = 8;
            // 
            // label1
            // 
            label1.Font = new Font("맑은 고딕", 20F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(45, 42);
            label1.Name = "label1";
            label1.Size = new Size(265, 83);
            label1.TabIndex = 9;
            label1.Text = "우리집냉장고";
            // 
            // button6
            // 
            button6.Location = new Point(1006, 631);
            button6.Name = "button6";
            button6.Size = new Size(112, 34);
            button6.TabIndex = 10;
            button6.Text = "개수알람";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // label2
            // 
            label2.Location = new Point(647, 482);
            label2.Name = "label2";
            label2.Size = new Size(350, 124);
            label2.TabIndex = 11;
            label2.Text = "라벨";
            label2.Click += label2_view;
            // 
            // label3
            // 
            label3.Location = new Point(336, 66);
            label3.Name = "label3";
            label3.Size = new Size(251, 38);
            label3.TabIndex = 12;
            label3.Text = "label3";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1578, 844);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(button6);
            Controls.Add(label1);
            Controls.Add(panel6);
            Controls.Add(panel5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Panel panel5;
        private Panel panel6;
        private Label label1;
        private Button button6;
        private Label label2;
        private Label label3;
    }
}