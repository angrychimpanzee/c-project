﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace real냉장고.panels
{
    public partial class 삭제panel : UserControl
    {
        public string FoodName { get; private set; }
        public int Food_Num { get; private set; }
        private bool isClosedByUser = false;
        public 삭제panel()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        public void ShowDialogCustom()
        {
            // Display the panel as a modal dialog
            Form form = new Form();
            form.StartPosition = FormStartPosition.CenterParent;
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.Controls.Add(this);
            form.ClientSize = this.Size;
            form.MaximizeBox = false;
            form.MinimizeBox = false;
            form.ShowInTaskbar = false;

            form.FormClosing += (sender, e) =>
            {
                if (!isClosedByUser)
                {
                    e.Cancel = true; // Prevent the form from closing if the user clicks the close button.
                }
            };

            form.ShowDialog();

            // Dispose the form after it's closed
            form.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FoodName = textBox1.Text;
            Food_Num = int.Parse(textBox2.Text);
            isClosedByUser = true;
            Form parentForm = this.ParentForm;
            parentForm.DialogResult = DialogResult.OK;
            parentForm.Close();
        }
    }
}
