﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace real냉장고.panels
{
    public partial class 데이터panel : UserControl
    {
        public 데이터panel()
        {
            InitializeComponent();
        }
    }
}
