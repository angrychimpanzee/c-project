﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace real냉장고.panels
{
    public partial class 추가panel : UserControl
    {
        public string FoodName { get; private set; }
        public DateTime BuyDate { get; private set; }
        public DateTime ExpDate { get; private set; }
        public bool IsFridge { get; private set; }
        
        public int Food_Num { get; private set; }

        private bool isClosedByUser = false; // Flag to track if the panel is closed by the user.


        public 추가panel()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FoodName = textBox1.Text;
            BuyDate = dateTimePicker1.Value;
            ExpDate = dateTimePicker2.Value;
            IsFridge = (comboBox1.SelectedIndex == 0);
            Food_Num = int.Parse(textBox2.Text);
            // Set the flag to indicate the panel is closed by the user.
            isClosedByUser = true;

            // Get the parent form and set the DialogResult to OK.
            Form parentForm = this.ParentForm;
            parentForm.DialogResult = DialogResult.OK;
            parentForm.Close();
        }
        public void ShowDialogCustom()
        {
            // Display the panel as a modal dialog
            Form form = new Form();
            form.StartPosition = FormStartPosition.CenterParent;
            form.FormBorderStyle = FormBorderStyle.FixedDialog;
            form.Controls.Add(this);
            form.ClientSize = this.Size;
            form.MaximizeBox = false;
            form.MinimizeBox = false;
            form.ShowInTaskbar = false;

            form.FormClosing += (sender, e) =>
            {
                if (!isClosedByUser)
                {
                    e.Cancel = true; // Prevent the form from closing if the user clicks the close button.
                }
            };

            form.ShowDialog();

            // Dispose the form after it's closed
            form.Dispose();
        }
    }
}
