using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace real냉장고
{


    public partial class Form1 : Form
    {
        panels.추가panel insert_panel = new panels.추가panel();
        panels.삭제panel delete_panel = new panels.삭제panel();
        panels.개수alarm_panel cnt_alarm_panel = new panels.개수alarm_panel();
        panels.데이터panel data_panel = new panels.데이터panel();
        private System.Windows.Forms.ListView listView2 = new System.Windows.Forms.ListView();
        private System.Windows.Forms.ListView listView3 = new System.Windows.Forms.ListView();
        private System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        private Dictionary<string, int> targetDict = new Dictionary<string, int>();
        string target_food_name = "";
        int target_num = 0;



        public Form1()
        {
            InitializeComponent();
            listView2.Location = new Point(632, 42);
            listView2.Size = new Size(398, 150);
            listView2.View = View.Details;
            listView2.Columns.Add("제품명", 200);
            listView2.Columns.Add("개수", 60);
            Controls.Add(listView2);
            listView3.Location = new Point(632, 274);
            listView3.Size = new Size(398, 150);
            listView3.View = View.Details;
            listView3.Columns.Add("제품명", 200);
            listView3.Columns.Add("개수", 60);
            Controls.Add(listView3);
            // 타이머 초기화
            timer.Interval = 1000; // 1초마다 갱신
            timer.Tick += Timer_Tick;
            timer.Start();


        }

        private List<Food> fridgeList = new List<Food>(); // 냉장품목 리스트
        private List<Food> freezerList = new List<Food>(); // 냉동품목 리스트



        private void UpdateLabel2()
        {
            int remainingCount = 0;
           
            if (fridgeList.Count + freezerList.Count > 0)
            {
                
                if (targetDict.TryGetValue(target_food_name, out target_num))
                {
                    
                    remainingCount = fridgeList.Where(f => f.name == target_food_name).Count() +
                                      freezerList.Where(f => f.name == target_food_name).Count();
                    if (remainingCount < target_num)
                    {
                        label2.Text = $"{target_food_name}가 {remainingCount}개밖에 안남았습니다";
                       
                    }
                    else
                    {
                        label2.Text = $"{target_food_name}가 {remainingCount}개 남았습니다";
                     
                    }
                }
                else
                {
                    label2.Text = $"{target_food_name}의 개수를 확인할 목록이 없습니다.";
                  
                }
            }
            else
            {
                label2.Text = "저장된 식재료가 없습니다.";
             
            }
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            // ListView 업데이트
            listView2.Items.Clear();
            listView3.Items.Clear();

            // 냉장고 리스트에서 제품 개수 계산
            Dictionary<string, int> fridgeDict = fridgeList.GroupBy(f => f.name)
                                                           .ToDictionary(g => g.Key, g => g.Count());
           
            foreach (var kvp in fridgeDict)
            {
                ListViewItem item = new ListViewItem(kvp.Key);
                item.SubItems.Add(kvp.Value.ToString());
                listView2.Items.Add(item);
            }
            
            Dictionary<string, int> freezerDict = freezerList.GroupBy(f => f.name)
                                                     .ToDictionary(g => g.Key, g => g.Count());
            foreach (var kvp in freezerDict)
            {
                ListViewItem item = new ListViewItem(kvp.Key);
                item.SubItems.Add(kvp.Value.ToString());
                listView3.Items.Add(item);
            }
          
            string time;

            DateTime now = DateTime.Now;
            time = now.ToString("HH:mm:ss");
            // 라벨 텍스트 설정         
            label3.Text = $"현재시간 {time}";


            UpdateLabel2();

        }
        private bool deleteFromList(List<Food> foodList, string food_name, int food_num, ref int deleted)
        {
            // food_name에 해당하는 품목이 리스트에 있는지 검색하고 있으면 food_num개만큼 삭제
            bool found = false;
            int count = 0;
            for (int i = foodList.Count - 1; i >= 0; --i)
            {
                if (foodList[i].name == food_name)
                {
                    found = true;
                    foodList.RemoveAt(i);
                    ++count;
                    if (count == food_num)
                    {
                        break;
                    }
                }
            }
            if (found)
            {
                if (count < food_num)
                {
                    MessageBox.Show($"현재 냉장고에 {count}개만 남아있습니다");
                }
                deleted += count;
            }
            return found;
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //panel1.Controls.Add(insert_panel);

            // 새로운 패널을 생성하고 모달 방식으로 띄움
            panels.추가panel addPanel = new panels.추가panel();
            addPanel.ShowDialogCustom();

            // 패널에서 입력된 정보를 받아와서 리스트에 추가
            Food food = new Food(addPanel.FoodName,
                                addPanel.BuyDate,
                                addPanel.ExpDate,
                                addPanel.IsFridge);
            int food_num = addPanel.Food_Num;


            if (food.is_fridge)
            {
                for (int i = 0; i < food_num; i++)
                {
                    fridgeList.Add(food);
                }

            }
            else
            {
                for (int i = 0; i < food_num; ++i)
                {
                    freezerList.Add(food);
                }

            }
            MessageBox.Show("재료가 추가되었습니다.");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 새로운 패널을 생성하고 모달 방식으로 띄움
            panels.삭제panel deletePanel = new panels.삭제panel();
            deletePanel.ShowDialogCustom();
            string food_name = deletePanel.FoodName;
            int food_num = deletePanel.Food_Num;
            int deleted = 0;
            if (food_num > 0)
            {
                if (deleteFromList(fridgeList, food_name, food_num, ref deleted))
                {
                    // 삭제에 성공한 경우
                }
                else if (deleteFromList(freezerList, food_name, food_num, ref deleted))
                {
                    // 삭제에 성공한 경우
                }
                else
                {
                    MessageBox.Show("해당 품목이 없습니다");
                }
            }
            MessageBox.Show(deleted + "개의 품목이 삭제되었습니다");
        }


        private void button3_Click(object sender, EventArgs e)
        {
            if (fridgeList.Count == 0 && freezerList.Count == 0)
            {
                MessageBox.Show("저장된 식재료가 없습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // 리스트 뷰를 만들고 폼에 추가합니다.
            System.Windows.Forms.ListView listView1 = new System.Windows.Forms.ListView();
            listView1.Location = new Point(1127, 114);
            listView1.Size = new Size(390, 522);
            listView1.View = View.Details;
            this.Controls.Add(listView1);

            // 열을 추가합니다.
            listView1.Columns.Add("이름", 60);
            listView1.Columns.Add("구매일시", 120);
            listView1.Columns.Add("유통기한", 60);
            listView1.Columns.Add("냉장/냉동", 60);

            // 저장된 식재료 정보를 하나씩 출력합니다.
            foreach (Food food in fridgeList)
            {
                // 유통기한 계산
                DateTime expDate = food.exp_date;
                TimeSpan timeDiff = expDate.Subtract(DateTime.Today);
                int daysToExpire = timeDiff.Days;

                // 식재료 정보를 리스트 뷰에 추가합니다.
                ListViewItem item = new ListViewItem(food.name);
                item.SubItems.Add(food.buy_date.ToString());
                item.SubItems.Add($"{daysToExpire}일");
                item.SubItems.Add("냉장");
                listView1.Items.Add(item);
            }

            foreach (Food food in freezerList)
            {
                // 유통기한 계산
                DateTime expDate = food.exp_date;
                TimeSpan timeDiff = expDate.Subtract(DateTime.Today);
                int daysToExpire = timeDiff.Days;

                // 식재료 정보를 리스트 뷰에 추가합니다.
                ListViewItem item = new ListViewItem(food.name);
                item.SubItems.Add(food.buy_date.ToString());
                item.SubItems.Add($"{daysToExpire}일");
                item.SubItems.Add("냉동");
                listView1.Items.Add(item);
            }

            // 패널의 닫기 버튼을 추가합니다.
            System.Windows.Forms.Button closeButton = new System.Windows.Forms.Button();
            closeButton.Text = "닫기";

            // 버튼 위치를 ListView 내부에서 표시되도록 수정합니다.
            Rectangle clientRect = listView1.ClientRectangle;
            closeButton.Location = new Point(clientRect.Right - closeButton.Width, clientRect.Bottom - closeButton.Height);
            listView1.Controls.Add(closeButton);

            // 닫기 버튼을 클릭하면 패널을 닫습니다.
            closeButton.Click += (s, ev) =>
            {
                listView1.Hide();
            };
        }


        private void button4_Click(object sender, EventArgs e)
        {

        }


        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        public void button6_Click(object sender, EventArgs e)
        {
            panels.개수alarm_panel cnt_Panel = new panels.개수alarm_panel();
            cnt_Panel.ShowDialogCustom();
            // 패널에서 입력된 정보를 받아와서 리스트에 추가
            this.target_food_name = cnt_Panel.FoodName;
            this.target_num = cnt_Panel.Food_Num;
            this.targetDict[target_food_name] = target_num;
            return;
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_view(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    public class Food
    {
        public string name { get; set; }
        public DateTime buy_date { get; set; }
        public DateTime exp_date { get; set; }
        public bool is_fridge { get; set; }
        public Food(string name, DateTime buy_date, DateTime exp_date, bool is_fridge)
        {
            this.name = name;
            this.buy_date = buy_date;
            this.exp_date = exp_date;
            this.is_fridge = is_fridge;
        }
    }
}